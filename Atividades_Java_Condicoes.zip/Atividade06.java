import java.util.Scanner;
public class Atividade06 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Média final: ");
        double media = sc.nextDouble();
        if (media >= 7) System.out.println("Aprovado");
        else if (media >= 5) System.out.println("Recuperação");
        else System.out.println("Reprovado");
    }
}