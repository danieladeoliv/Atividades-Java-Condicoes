import java.util.Scanner;
public class Atividade08 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double temp = sc.nextDouble();
        if (temp > 30) System.out.println("Quente");
        else if (temp >= 15) System.out.println("Agradável");
        else System.out.println("Frio");
    }
}