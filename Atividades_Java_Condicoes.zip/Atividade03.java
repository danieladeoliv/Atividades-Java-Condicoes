public class Atividade03 {
    public static void main(String[] args) {
        int numero = 7;
        if (numero % 2 == 0) System.out.println("Par");
        else System.out.println("Ímpar");
    }
}