import java.util.Scanner;
public class Atividade11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double salario = sc.nextDouble();
        int anos = sc.nextInt();
        double bonus = 0;
        if(anos>10) bonus=salario*0.10;
        else if(anos>=5) bonus=salario*0.05;
        double imposto;
        if(salario>5000) imposto=salario*0.27;
        else if(salario>=3000) imposto=salario*0.18;
        else imposto=salario*0.10;
        double liquido = salario + bonus - imposto;
        System.out.println("Salário bruto: R$"+salario);
        System.out.println("Bônus: R$"+bonus);
        System.out.println("Imposto: R$"+imposto);
        System.out.println("Salário líquido: R$"+liquido);
    }
}