public class Atividade02 {
    public static void main(String[] args) {
        double nota = 8.5;
        if (nota >= 9) System.out.println("Excelente");
        else if (nota >= 7) System.out.println("Bom");
        else if (nota >= 5) System.out.println("Satisfatório");
        else System.out.println("Insatisfatório");
    }
}