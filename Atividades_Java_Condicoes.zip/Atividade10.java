import java.util.Scanner;
public class Atividade10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double valor = sc.nextDouble();
        double desconto=0;
        if(valor>500) desconto=20;
        else if(valor>=200) desconto=10;
        else if(valor>=100) desconto=5;
        double valorDesc = valor*desconto/100;
        System.out.println("Valor original: R$"+valor);
        System.out.println("Desconto: "+desconto+"%");
        System.out.println("Valor descontado: R$"+valorDesc);
        System.out.println("Valor final: R$"+(valor-valorDesc));
    }
}