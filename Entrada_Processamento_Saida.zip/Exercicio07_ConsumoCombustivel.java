import java.util.Scanner;
public class Exercicio07_ConsumoCombustivel{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String motorista = sc.nextLine();
        double distancia = sc.nextDouble();
        double litros = sc.nextDouble();
        double consumo = distancia / litros;
        System.out.println("Motorista: " + motorista);
        System.out.println("Consumo médio: " + consumo + " km/l");
    }
}