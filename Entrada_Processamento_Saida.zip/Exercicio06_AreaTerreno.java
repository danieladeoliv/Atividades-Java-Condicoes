import java.util.Scanner;
public class Exercicio06_AreaTerreno{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String proprietario = sc.nextLine();
        double comprimento = sc.nextDouble();
        double largura = sc.nextDouble();
        double area = comprimento * largura;
        System.out.println("Proprietário: " + proprietario);
        System.out.println("Área: " + area + " m²");
    }
}