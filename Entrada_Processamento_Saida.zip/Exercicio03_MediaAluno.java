import java.util.Scanner;
public class Exercicio03_MediaAluno{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String nome = sc.nextLine();
        double n1 = sc.nextDouble();
        double n2 = sc.nextDouble();
        double n3 = sc.nextDouble();
        double media = (n1+n2+n3)/3;
        System.out.println("Aluno: " + nome);
        System.out.println("Média: " + media);
    }
}