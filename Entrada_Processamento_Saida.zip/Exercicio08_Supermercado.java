import java.util.Scanner;
public class Exercicio08_Supermercado{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String p1=sc.nextLine(); double pr1=sc.nextDouble(); int q1=sc.nextInt(); sc.nextLine();
        String p2=sc.nextLine(); double pr2=sc.nextDouble(); int q2=sc.nextInt(); sc.nextLine();
        String p3=sc.nextLine(); double pr3=sc.nextDouble(); int q3=sc.nextInt();

        double s1=pr1*q1, s2=pr2*q2, s3=pr3*q3;
        double total=s1+s2+s3;

        System.out.println(p1 + ": R$" + s1);
        System.out.println(p2 + ": R$" + s2);
        System.out.println(p3 + ": R$" + s3);
        System.out.println("Total: R$" + total);
    }
}