import java.util.Scanner;
public class Exercicio10_Viagem{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String motorista = sc.nextLine();
        double distancia = sc.nextDouble();
        double consumo = sc.nextDouble();
        double preco = sc.nextDouble();
        int pessoas = sc.nextInt();

        double litros = distancia/consumo;
        double custo = litros*preco;

        System.out.println("Motorista: " + motorista);
        System.out.println("Litros necessários: " + litros);
        System.out.println("Custo estimado: R$ " + custo);
        System.out.println("Custo por pessoa: R$ " + (custo/pessoas));
    }
}