import java.util.Scanner;
public class Desafio_Churrasco{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int pessoas = sc.nextInt();
        double precoCarne = sc.nextDouble();
        double precoRefri = sc.nextDouble();
        int qtdRefri = sc.nextInt();
        double acompanhamentos = sc.nextDouble();

        double kgCarne = (pessoas * 0.4);
        double valorCarne = kgCarne * precoCarne;
        double valorRefri = precoRefri * qtdRefri;
        double total = valorCarne + valorRefri + acompanhamentos;

        System.out.println("Carne necessária: " + kgCarne + " kg");
        System.out.println("Valor carne: R$ " + valorCarne);
        System.out.println("Valor refrigerantes: R$ " + valorRefri);
        System.out.println("Total: R$ " + total);
        System.out.println("Por participante: R$ " + (total/pessoas));
    }
}