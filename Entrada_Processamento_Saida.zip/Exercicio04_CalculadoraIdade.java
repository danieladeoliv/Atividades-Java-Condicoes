import java.util.Scanner;
public class Exercicio04_CalculadoraIdade{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String nome = sc.nextLine();
        int nasc = sc.nextInt();
        int atual = sc.nextInt();
        System.out.println(nome + " possui aproximadamente " + (atual-nasc) + " anos.");
    }
}