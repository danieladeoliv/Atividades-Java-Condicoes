import java.util.Scanner;
public class Exercicio05_Salario{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String nome = sc.nextLine();
        double horas = sc.nextDouble();
        double valorHora = sc.nextDouble();
        double salario = horas * valorHora;
        System.out.println("Funcionário: " + nome);
        System.out.println("Salário: R$ " + salario);
    }
}