import java.util.Scanner;
public class Exercicio09_DivisaoConta{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        double consumo = sc.nextDouble();
        double taxa = sc.nextDouble();
        int pessoas = sc.nextInt();
        double total = consumo + taxa;
        System.out.println("Valor total: R$ " + total);
        System.out.println("Por pessoa: R$ " + (total/pessoas));
    }
}